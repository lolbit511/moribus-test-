Do not move anything outside this file
it will break the game

to run the game, click on the exe file while inside this folder
----------------------------------------------------------------------------------
	Controls:
Left click - melee
Right click - fireball 
n - advances to next stage (if there are no enemies on screen)
e - interract with map
space/w - jump
a - left
d - right
s - sheild (blocks 100% of projectile damage, 80% of melee damage)
-------------------------------------------------------------------------------------------------------------
	Buttons on bottom right of screen: (left to right)
load - loads game
save - saves game (currently can only have one save file)
home - returns to the screen with the map
pause/play - pauses/unpauses game (enemies disapear when game is paused)
-------------------------------------------------------------------------------------------------------------
	Stats
Health - Health can be lowered by contacting enemies or their porjectiles, if health falls below 0, you lose
Stage - Indicates difficulty (number of enemies)
EXP - Indicates progress, can be increased by killing enemies
Mana - Used to hold sheild up or cast spells
Purse - Can be increased by picking up coins
FPS - Frames per seconds
-------------------------------------------------------------------------------------------------------------
There are currently 3 types of enemies, and two stages (accessed by the map)